Directory structure and decription:
(/groups/hbctraining/unix_oct2015/)

raw_fastq/	# 6 raw fastq files
reference_data/	# chr1 fasta, chr1 indexed, chr1 annotation/gtf
genomics_data/	# other file formats that they will not be generating in class (bed, sam, vcf?)
other/		# hidden directories with final results for emergency
  bam_output/	
  counts/
  trimmed_fastq/
  fastqc/
